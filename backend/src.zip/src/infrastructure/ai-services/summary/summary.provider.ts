import { Provider } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SUMMARY_SERVICE } from '../../../core/interfaces/services/summary.interface';
import { SummaryType } from '../../config/ai.config';
import { BasicSummaryService } from './basic-summary.service';
import { OpenAiSummaryService } from './openai-summary.service';

export const summaryProvider: Provider = {
  provide: SUMMARY_SERVICE,
  useFactory: (configService: ConfigService) => {
    const type =
      configService.get<SummaryType>('SUMMARY_TYPE') || SummaryType.BASIC;

    switch (type) {
      case SummaryType.OPENAI:
        return new OpenAiSummaryService(configService);
      case SummaryType.BASIC:
      default:
        return new BasicSummaryService();
    }
  },
  inject: [ConfigService],
};
