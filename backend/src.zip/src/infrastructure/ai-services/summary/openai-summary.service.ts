// src/services/implementations/OpenAISummaryService.ts
import OpenAI from 'openai';
import { ISummaryService } from 'src/core/interfaces/services/summary.interface';

export class OpenAISummaryService implements ISummaryService {
  private client: OpenAI;

  constructor(apiKey: string) {
    this.client = new OpenAI({ apiKey });
  }

  async summarize(texts: string[]): Promise<string> {
    const combined = texts.join('\n\n');

    const response = await this.client.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content:
            'You are a therapist assistant. Summarize therapy session transcripts professionally.',
        },
        {
          role: 'user',
          content: `Summarize this therapy session:\n\n${combined}`,
        },
      ],
      max_tokens: 500,
    });

    return response.choices[0].message.content || 'No summary generated';
  }
}
