// src/services/implementations/AssemblyAITranscriptionService.ts
import { AssemblyAI } from 'assemblyai';
import { ITranscriptionService } from 'src/core/interfaces/services/transcription.interface';

export class AssemblyAITranscriptionService implements ITranscriptionService {
  private client: AssemblyAI;

  constructor(apiKey: string) {
    this.client = new AssemblyAI({ apiKey });
  }

  async transcribe(audioPath: string): Promise<TranscribedEntry[]> {
    const transcript = await this.client.transcripts.transcribe({
      audio: audioPath,
      speaker_labels: true, // Enable diarization
    });

    if (transcript.status === 'error') {
      throw new Error(`Transcription failed: ${transcript.error}`);
    }

    const entries: TranscribedEntry[] = [];
    const utterances = transcript.utterances || [];

    for (const utterance of utterances) {
      entries.push({
        speaker: utterance.speaker === 'A' ? 'Therapist' : 'Patient',
        text: utterance.text,
        startTime: utterance.start,
        endTime: utterance.end,
      });
    }

    return entries;
  }
}
