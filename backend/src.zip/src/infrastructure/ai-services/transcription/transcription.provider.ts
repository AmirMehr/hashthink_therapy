import { Provider } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TRANSCRIPTION_SERVICE } from '../../../core/interfaces/services/transcription.interface';
import { TranscriptionType } from '../../config/ai.config';
import { MockTranscriptionService } from './mock-transcription.service';
import { AssemblyAiTranscriptionService } from './assemblyai-transcription.service';

export const transcriptionProvider: Provider = {
  provide: TRANSCRIPTION_SERVICE,
  useFactory: (configService: ConfigService) => {
    const type =
      configService.get<TranscriptionType>('TRANSCRIPTION_TYPE') ||
      TranscriptionType.MOCK;

    switch (type) {
      case TranscriptionType.ASSEMBLYAI:
        return new AssemblyAiTranscriptionService(configService);
      case TranscriptionType.MOCK:
      default:
        return new MockTranscriptionService();
    }
  },
  inject: [ConfigService],
};
