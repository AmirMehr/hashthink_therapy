import { Provider } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { EMBEDDING_SERVICE } from '../../../core/interfaces/services/embedding.interface';
import { EmbeddingType } from '../../config/ai.config';
import { MockEmbeddingService } from './mock-embedding.service';
import { OpenAiEmbeddingService } from './openai-embedding.service';

export const embeddingProvider: Provider = {
  provide: EMBEDDING_SERVICE,
  useFactory: (configService: ConfigService) => {
    const type =
      configService.get<EmbeddingType>('EMBEDDING_TYPE') || EmbeddingType.MOCK;

    switch (type) {
      case EmbeddingType.OPENAI:
        return new OpenAiEmbeddingService(configService);
      case EmbeddingType.MOCK:
      default:
        return new MockEmbeddingService();
    }
  },
  inject: [ConfigService],
};
