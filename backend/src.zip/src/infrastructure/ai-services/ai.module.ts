import { Module } from '@nestjs/common';
import { transcriptionProvider } from './transcription/transcription.provider';
import { embeddingProvider } from './embedding/embedding.provider';
import { summaryProvider } from './summary/summary.provider';

@Module({
  providers: [transcriptionProvider, embeddingProvider, summaryProvider],
  exports: [transcriptionProvider, embeddingProvider, summaryProvider],
})
export class AiModule {}
