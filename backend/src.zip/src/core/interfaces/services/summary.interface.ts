export interface ISummaryService {
  summarize(texts: string[]): Promise<string>;
}

export const SUMMARY_SERVICE = Symbol('ISummaryService');
