export interface TranscriptionSegment {
  text: string;
  speaker: string;
  start: number;
  end: number;
}

export interface ITranscriptionService {
  transcribe(audioPath: string): Promise<TranscriptionSegment[]>;
}

export const TRANSCRIPTION_SERVICE = Symbol('ITranscriptionService');
